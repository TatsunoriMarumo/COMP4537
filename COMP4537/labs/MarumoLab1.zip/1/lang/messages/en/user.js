export const messages = {
    title: "Lab 1: JSON, Object Constructor, localStorage",
    name: "Tatsunori Marumo",
    writerBtnLabel: "Go to Writer Page",
    readerBtnLabel: "Go to Reader Page",
    noteTitle: "%1.html",
    removeBtnText: "remove",
    addBtnText: "add",
    backBtnText: "back",
    storedTimeStamp: "stored at %1",
    updatedTimeStamp: "updated at %1"
}
